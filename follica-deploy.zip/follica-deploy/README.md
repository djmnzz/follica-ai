# 🚀 Follica AI - Deployment Guide

## 📦 Lo que tienes aquí:

- `index.html` - Tu app completa con API integrada
- `netlify.toml` - Configuración para Netlify

---

## 🌐 OPCIÓN 1: Netlify Drop (MÁS FÁCIL - 30 segundos)

### Paso a Paso:

1. **Ve a:** https://app.netlify.com/drop

2. **Arrastra TODA la carpeta `follica-deploy`** a la zona de drop

3. **¡Listo!** En 10 segundos tendrás un link como:
   ```
   https://follica-ai-abc123.netlify.app
   ```

4. **Comparte el link** y accede desde cualquier lugar

### ✅ Ventajas:
- ✅ Gratis forever
- ✅ HTTPS automático
- ✅ Sin registro (opcional)
- ✅ Funciona instantáneamente

---

## 🌐 OPCIÓN 2: Vercel (También gratis)

1. **Ve a:** https://vercel.com/new

2. **Arrastra la carpeta** o conecta desde GitHub

3. **Deploy** → Listo en 20 segundos

---

## 🌐 OPCIÓN 3: GitHub Pages (Gratis + Custom domain)

### Paso 1: Sube a GitHub

1. Ve a https://github.com/new
2. Crea repositorio: `follica-ai`
3. Sube estos archivos

### Paso 2: Habilita GitHub Pages

1. Repo → Settings → Pages
2. Source: `main` branch
3. Save

Tu sitio estará en:
```
https://tu-usuario.github.io/follica-ai
```

---

## 🔒 Seguridad

**IMPORTANTE:** Tu API token está en el código HTML. 

Para producción considera:
1. **Variables de entorno** (Netlify/Vercel soportan esto)
2. **Backend proxy** (oculta el token completamente)
3. **Rate limiting** en Replicate

Para uso personal/demo está bien, pero para uso público largo plazo, considera mover el token a un backend.

---

## ⚡ Después de deployar:

1. **Prueba el link** que te den
2. **Sube una foto**
3. **Genera resultado**
4. **¡Funciona!** 🎉

---

## 📱 Mobile Friendly

La app funciona perfectamente en:
- ✅ iPhone/iPad
- ✅ Android
- ✅ Desktop
- ✅ Tablet

---

## 🎯 Custom Domain (Opcional)

Si tienes un dominio propio:

**Netlify:**
- Settings → Domain management → Add custom domain
- Agrega: `follica.tudominio.com`
- Configura DNS según instrucciones

**Vercel:**
- Settings → Domains → Add
- Sigue instrucciones

---

## 🆘 ¿Problemas?

Si el deploy falla:
1. Verifica que ambos archivos estén en la carpeta
2. Intenta Netlify Drop primero (es lo más fácil)
3. Asegúrate de arrastrar la CARPETA completa, no solo el HTML

---

## 🎉 ¡Listo!

Una vez deployado, tu app estará online 24/7, accesible desde cualquier lugar del mundo.

**Link típico de Netlify:**
```
https://tu-nombre-de-app.netlify.app
```

¡Disfruta tu app de IA en vivo! 🚀💇‍♂️
